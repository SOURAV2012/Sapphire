import java.util.HashMap;
import java.util.Map;

/*
 * In PCB class frames are initialized.
 * Segment Table is Created here.
 * Page Map Table is Created here.
 * 
 */
public class PCB {
	
	

	/*//	pageFrame
	 * 
	 * 0 -> Page Num
	 * 1 -> Reference bit
	 * 2 -> Dirty bit
	 */
	
	/*
	 * Segment->
	 * 
	 * Index
	 * BaseAddr(memory frame)
	 * Length
	 * 
	 */
	
	public  int[][]segmentTable = new int[3][3];  //max segment 3 (program,input,output)
	
	public  int[][][]pageFrameTableCollect = new int[3][32][3]; 
	
	private static Map<Integer,PCB> pcbMapper = new HashMap<Integer,PCB>();
	
	private Integer jobId;
	private Integer programCounter;
	private int programSegment = -1;
	private int inputSegment = -1;
	private int outputSegment = -1;
	private Integer loadAddrs;
	private Integer initialProgramCounter;
	private Integer jobSize;
	private Integer trace;
	private Integer prgmDskStartPos;
	private Integer prgmDskEndPos;
	private Integer inputDskStartPos;
	private Integer inputDskEndPos;
	
	
	private int pageFrame1 = 5;
	private int pageFrame2 = 8;
	private int pageFrame3 = 10;		
	private int pageFrame4 = 17;
	private int pageFrame5 = 20;
	private int pageFrame6 = 31;
	
	private PCB(int jobId){
		this.jobId = jobId;
	}
	
	public static synchronized  PCB getInstance(Integer jobId){	
		
		if(!pcbMapper.containsKey(jobId)){
			pcbMapper.put(jobId,new PCB(jobId));
		}
		return pcbMapper.get(jobId);
}
	
	public Integer getJobId() {
		return jobId;
	}
	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}
	public int getProgramSegment() {
		return programSegment;
	}
	public void setProgramSegment(int programSegment) {
		this.programSegment = programSegment;
	}
	public int getInputSegment() {
		return inputSegment;
	}
	public void setInputSegment(int inputSegment) {
		this.inputSegment = inputSegment;
	}
	public int getOutputSegment() {
		return outputSegment;
	}
	public void setOutputSegment(int outputSegment) {
		this.outputSegment = outputSegment;
	}
	public int getPageFrame1() {
		return pageFrame1;
	}
	public void setPageFrame1(int pageFrame1) {
		this.pageFrame1 = pageFrame1;
	}
	public int getPageFrame2() {
		return pageFrame2;
	}
	public void setPageFrame2(int pageFrame2) {
		this.pageFrame2 = pageFrame2;
	}
	public int getPageFrame3() {
		return pageFrame3;
	}
	public void setPageFrame3(int pageFrame3) {
		this.pageFrame3 = pageFrame3;
	}
	public int getPageFrame4() {
		return pageFrame4;
	}
	public void setPageFrame4(int pageFrame4) {
		this.pageFrame4 = pageFrame4;
	}
	public int getPageFrame5() {
		return pageFrame5;
	}
	public void setPageFrame5(int pageFrame5) {
		this.pageFrame5 = pageFrame5;
	}
	public int getPageFrame6() {
		return pageFrame6;
	}
	public void setPageFrame6(int pageFrame6) {
		this.pageFrame6 = pageFrame6;
	}

	public Integer getProgramCounter() {
		return programCounter;
	}

	public void setProgramCounter(Integer programCounter) {
		this.programCounter = programCounter;
	}

	public Integer getLoadAddrs() {
		return loadAddrs;
	}

	public void setLoadAddrs(Integer loadAddrs) {
		this.loadAddrs = loadAddrs;
	}

	public Integer getInitialProgramCounter() {
		return initialProgramCounter;
	}

	public void setInitialProgramCounter(Integer initialProgramCounter) {
		this.initialProgramCounter = initialProgramCounter;
	}

	public Integer getJobSize() {
		return jobSize;
	}

	public void setJobSize(Integer jobSize) {
		this.jobSize = jobSize;
	}

	public Integer getTrace() {
		return trace;
	}

	public void setTrace(Integer trace) {
		this.trace = trace;
	}

	
	public Integer getInputDskStartPos() {
		return inputDskStartPos;
	}

	public void setInputDskStartPos(Integer inputDskStartPos) {
		this.inputDskStartPos = inputDskStartPos;
	}

	public Integer getInputDskEndPos() {
		return inputDskEndPos;
	}

	public void setInputDskEndPos(Integer inputDskEndPos) {
		this.inputDskEndPos = inputDskEndPos;
	}

	public Integer getPrgmDskStartPos() {
		return prgmDskStartPos;
	}

	public void setPrgmDskStartPos(Integer prgmDskStartPos) {
		this.prgmDskStartPos = prgmDskStartPos;
	}

	public Integer getPrgmDskEndPos() {
		return prgmDskEndPos;
	}

	public void setPrgmDskEndPos(Integer prgmDskEndPos) {
		this.prgmDskEndPos = prgmDskEndPos;
	}

	public int[][] getSegmentTable() {
		return segmentTable;
	}

	public int[][][] getPageFrameTableCollect() {
		return pageFrameTableCollect;
	}

	
	
}
