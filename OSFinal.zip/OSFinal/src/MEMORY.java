/*
 *  Global Variables
 *  1. jobId - It is in two digit HEX form and it gives the job id of the input loader format
 *  2. loadAddr - It is in two digit HEX form and it gives the base address of the input loader format
 *  3. initialPC - It is in two digit HEX  form and it shows the initial program counter from where loader input starts executing
 *  4. size - It is in two digit HEX form and it is the length of the job
 *  5. trace - It is in one digit HEX form and if it is enable it will create trace_file, where PC, IR, BR, TOS before and after, S[TOS] before and after is 
 *  
 *  -> The pages from DISC called to loader and send it to MEMORY.
 *  -> pages are loaded in frames.
 *  -> Storing Binary converted words in MainMemory.
 *  Handling Page Fault.
 *  Handling Segment Fault.
 *  
 *  
 */

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;

public class MEMORY {
	
	
	public static char MainMemory[][] = new char[256][16];
	

	
	public static Set<Integer> frameset = new HashSet<Integer>();
	public static Set<Integer> pageset = new HashSet<Integer>();
	public static int __memoryLoc = 0;
	public static byte jobId;
	public static byte loadAddr;
	public static byte initialPc;
	private static byte size;
	public static byte trace;
	
	//For reading disk address
	//For writing actual Memory address
	
	public static String memoryProc(int rw,int pos,String var){
		if(pos>255){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER111);
		}
		if(rw==1){		
			if(var.length()!=16){
				ERROR_HANDLER.handle(ERROR_HANDLER.ER101);
			}
			
			write(pos,var);
		
		}else{
			var = read(pos);
		}
		return var;
	}
	
	//****** Adding words to MainMemory (write) ******//


	private static void write(int pos,String bin){
		
		
		MainMemory[pos] = bin.toCharArray();
		
	}
	
	//*********** Calculating Page location from DISC to get word address**********//
	
	public static void reswrite(int dskAddress,String bin){		
		
		System.out.println("POP WRITE ADR - "+dskAddress+" - "+bin);
		System.out.println("RD ADDR "+read(dskAddress));

				int segment = pageSegmentFromDskAddrs(dskAddress);
				System.out.println("Seg :"+segment);
				if(!read(dskAddress).isEmpty()){
					int page = pageNumFromDskAddrs(dskAddress);
					int frame = frameFromPageNum(page,segment);
					int posinmem = (frame * 8) + (dskAddress % 8);
					System.out.println("posinmem - "+posinmem);
					MainMemory[posinmem] = bin.toCharArray();								
					PCB.pageFrameTableCollect[segment][frame][2] = 1;			//update dirty bit
					System.out.println("ONE LAT READ "+dskAddress+" - "+read(dskAddress));
			
				}
				System.out.println("DISK ADDRS FLUSH : "+dskAddress+" - "+new String(DISC.readFromDisk(dskAddress)));
			
		}
		
	
	private static String read(int dskAddr){
		

		int segment = pageSegmentFromDskAddrs(dskAddr);

		int page = pageNumFromDskAddrs(dskAddr);

		int frame = frameFromPageNum(page,segment);

		int posinmem = 0;

		if(frame == -1){
			PAGEFAULT_HANDLER.handle(page,segment);

			frame = frameFromPageNum(page,segment);
			posinmem = (frame * 8) + (dskAddr % 8);
		}else{			
			 posinmem = (frame * 8) + (dskAddr % 8);
	
			 PCB.pageFrameTableCollect[segment][frame][1] = 1;				//update reference bit
		}
		return new String(MainMemory[posinmem]);	
	}
	
	public static void mload(int dskAddr,int segment){
		
		int page = pageNumFromDskAddrs(dskAddr);
		int frame = frameFromPageNum(page,segment);
		LOADER.loadFrameToMemory(frame, segment);
	}
	
	//******* Storing one word in each location (16 bits) ******//
	
	private static void addToMemory(String bin,char[][] memory,int memoryLoc){
		
		 
		memory[memoryLoc] = bin.toCharArray();
		
		
	}
	
	
	
	//********** Fetched HEX word from the loader converted in Binary******//

	private static String hexToBinary(String hex) {
	    int i = Integer.parseInt(hex, 16);
	    String bin = Integer.toBinaryString(i);
	    return bin;
	}
	
	
	
	
	
	public static void addJobParams(String hex){
		
		try{
			System.out.println("JOB_ID :: "+ hex.substring(0, 2));
			System.out.println("LOAD ADDR :: " +hex.substring(3, 5));
			System.out.println("INITIAL_PC :: "+hex.substring(6, 8));
			System.out.println("SIZE :: "+hex.substring(9, 11));
			System.out.println("TRACE FLAG :: "+hex.substring(12, 13));
		}catch(Exception e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER112);
		}
		
		
		if((!hex.substring(12, 13).trim().equals("0")) && (!hex.substring(12, 13).trim().equals("1"))){
			ERROR_HANDLER.handle(ERROR_HANDLER.WR202);
		}	
		
		try{
			jobId = (byte) Integer.parseInt(hex.substring(0, 2), 16);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER107);
		}
		
		try{
			loadAddr = (byte) Integer.parseInt(hex.substring(3, 5), 16);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER108);
		}
		
		try{
			initialPc = (byte) Integer.parseInt(hex.substring(6, 8), 16);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER109);
		}
		
		try{
			size = (byte) Integer.parseInt(hex.substring(9, 11), 16);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER110);
		}
	
		
			
		trace = (byte) Integer.parseInt(hex.substring(12, 13), 16);
		
		
			
	}
	
	//*******Printing MainMemory in Binary*******//
	
	public static void printMemorySnapshot(){	
		
		System.out.println("===================MEMORY SNAPSHOT=========================");
		for(int i = 0; i<MEMORY.MainMemory.length; i++)
		{
			System.out.print(i+"-->");
		    for(int j = 0; j<16; j++)		    
		        System.out.print(MEMORY.MainMemory[i][j]);		    
		    System.out.println();
		}		
		System.out.println("========================================================");
		
	}
	
	//******* Printing trace_file******//
	
	
	public static int pageSegmentFromDskAddrs(int dskAddress){

		int segment = resolveSegment(dskAddress);
		int segmentTabVal = PCB.segmentTable[segment][0];

		if(segmentTabVal == -1){

			LOADER.addSegmentTable(segment,0,DISC.counter);
			PCB.getInstance(CPU.currentJob).setProgramSegment(segment);
			segmentTabVal = PCB.segmentTable[segment][0];
		}
		return segmentTabVal;
	}
	
	//*************** Getting page number from Disc Address ************//
	
	public static int pageNumFromDskAddrs(int dskAddress){
		int page = 0;
		if(dskAddress < 8)
			page = 0;
		else
			page = (dskAddress / 8);
		pageset.add(page);
		return page;
	}
	
	//*************** Frames in MEMORY ***********//
	public static int frameFromPageNum(int pageNum,int segment){
		int frameNum = -1;
		
		for(int i=0 ; i<32 ;i++){
			int temp[] = PCB.pageFrameTableCollect[segment][i];
			if(temp[0]==pageNum){
				frameNum = i;
				frameset.add(frameNum);
			}
		}
		return frameNum;
	}
	
	
//**************** Page Replacement Algorithm ***********//
	
	private static int resolveSegment(int dskAddress){
		int segment = -1;
		if(dskAddress < 71){
			segment = 0;
		}else if(dskAddress >= 72 && dskAddress < 80){
			segment = 1;
		}else{
			segment = 2;
		}
		return  0;
	}
	
	//*********** Memory Utilization **********//
	public static void  printMemoryUtilz(){
		
		int used = 0 ;
		for(int i = 0; i< MainMemory.length;i++){
				if(! new String(MainMemory[i]).trim().isEmpty()){
					used++;
				}
		}
		double ratio = (double)used/MainMemory.length;
		System.out.println("MEMORY UTILIZATION WORDS --  Ratio :"+ ratio + "  Percentage :"+(ratio *100) +"%");
		ratio = ((double)frameset.size()/32);
		System.out.println("MEMORY UTILIZATION FRAMES --  Ratio :"+ ratio + "  Percentage :"+(ratio *100) +"%");
	}
	
	//*************** Memory Fragmentation **************//
	
	public static void printMemFragmentation(){
		
		Deque deque = (Deque) LOADER.fmtQueue;

		int lastframe = 31;
		int mempos = lastframe * 8;
		int pageno = PCB.pageFrameTableCollect[0][lastframe][0];
		int emptyCount = 0;
		for(int i=0 ;i<8 ;i++){			
			 String item = new String(MainMemory[mempos + i]);
			 if(item.trim().isEmpty())
				 emptyCount++;			 
		}	
		int progEmptyCount = (8- (DISC.counter%8) - 1);
		
		System.out.println("MEMORY FRAGMENTATION :: "+emptyCount);
		
	}

}


//************** Handling Page Faults ************//
/*
 * Only 6 frames are available: 5, 8, 10, 17, 20, 31.
 */

 class PAGEFAULT_HANDLER {
	
	 public static int PF_CLOCK = 0;
	
	public static void handle(int page,int segment){
		System.out.println("PAGE FAULT OCCURED :: "+ page);
		
		SYSTEM.clock = SYSTEM.clock  + 10;
		PF_CLOCK = PF_CLOCK +10;
		SYSTEM.logClock();
		
		if(isEmpty(PCB.pageFrameTableCollect[segment][5])){
			PCB.pageFrameTableCollect[segment][5] = new int[]{page,0,0};
			LOADER.fmtQueue.add(5);
			LOADER.loadFrameToMemory(5,segment);
		}else if(isEmpty(PCB.pageFrameTableCollect[segment][8])){
			PCB.pageFrameTableCollect[segment][8] = new int[]{page,0,0};
			LOADER.fmtQueue.add(8);
			LOADER.loadFrameToMemory(8,segment);
		}else if(isEmpty(PCB.pageFrameTableCollect[segment][10])){
			PCB.pageFrameTableCollect[segment][10] = new int[]{page,0,0};
			LOADER.fmtQueue.add(10);
			LOADER.loadFrameToMemory(10,segment);
		}else if(isEmpty(PCB.pageFrameTableCollect[segment][17])){
			PCB.pageFrameTableCollect[segment][17] = new int[]{page,0,0};
			LOADER.fmtQueue.add(17);
			LOADER.loadFrameToMemory(17,segment);
		}else if(isEmpty(PCB.pageFrameTableCollect[segment][20])){
			PCB.pageFrameTableCollect[segment][20] = new int[]{page,0,0};
			LOADER.fmtQueue.add(20);
			LOADER.loadFrameToMemory(20,segment);
		}else if(isEmpty(PCB.pageFrameTableCollect[segment][31])){
			PCB.pageFrameTableCollect[segment][31] = new int[]{page,0,0};
			LOADER.fmtQueue.add(31);
			LOADER.loadFrameToMemory(31,segment);
		}else{
			int frame = getReplacementFrame(segment);
			
			if(PCB.pageFrameTableCollect[segment][frame][2] == 1)
				LOADER.flushFrameToDisk(frame,segment);
			
			PCB.pageFrameTableCollect[segment][frame] = new int[]{page,0,0};
			LOADER.loadFrameToMemory(frame,segment);
		}
	}
	
	
	private static boolean isEmpty(int[] frmRow){
		return (frmRow[0] == -1 && frmRow[1] == -1  && frmRow[2] == -1);
	}
	
	//********** Replacing Frames or Pages *********//
	
	private static int getReplacementFrame(int segment){
		
		boolean fflag = false;
		int sthead = LOADER.fmtQueue.peek();	
		
		while(true){
	
			int head = LOADER.fmtQueue.poll();		
			int[] frmTbEnt = PCB.pageFrameTableCollect[segment][head];
			if(frmTbEnt[1]== 1){
				if(fflag == true && sthead==head){
					return head;
				}else{
					LOADER.fmtQueue.add(head);  // if ref bit is 1 then add at the bottom of the queue
				}
			}else{
				return head;
			}			
			fflag = true;
		}
	}	
	
}

//***************** Handling Segment Fault ***********//
 
class SEGMENT_FAULT {
		
		public static int SF_CLOCK= 0;
		public static void  handle(int segment){
			
			System.out.println("SEGMENT FAULT OCCURED :: "+segment);
			
			
			int val = (DISC.counter + (8-(DISC.counter % 8)));	
			if(PCB.segmentTable[segment][0] != segment){
				if(segment == 0){
				
					LOADER.addSegmentTable(segment,0,DISC.counter);
					PCB.getInstance(CPU.currentJob).setProgramSegment(segment);
				}else if(segment == 1){
				
					LOADER.addSegmentTable(segment,val,(val+7));
					
					PCB.getInstance(CPU.currentJob).setInputSegment(segment);
				}else{
				
					LOADER.addSegmentTable(segment,(val +8),(val + 15));
					PCB.getInstance(CPU.currentJob).setOutputSegment(segment);
				}
				
				SYSTEM.clock = SYSTEM.clock  + 5;
				SF_CLOCK = SF_CLOCK +5;
				SYSTEM.logClock();
				System.out.println("PR SEG : "+Arrays.toString(PCB.segmentTable[1]));
			}
		}
		
	}
