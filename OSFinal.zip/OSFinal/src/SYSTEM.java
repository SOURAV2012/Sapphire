/*
 *  Name : Ipsita Ghosh
 *  
 *  Course Number : CS 5323
 *  
 *  Assignment Title : A Simple Batch System ( Phase 2)
 *  
 *  Date : 04/03/2918
 *  
 *  Description of Global Variable :
 *  in - USER Input 
 *  clock - calculating the clock time 
 *  out - Output in console
 *  IOClock - calculating the IO Clock time
 *  tempclock - calculating interval time for printing pmt for every 15 clock
 *  disclock - giving disc location
 * Reading the input loader format
 * For IO additional clock is 15
 * printing in output file
 * SYSTEM sending data to DISC in binary format
 * 
 */
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class SYSTEM {
	
	private static List<Integer> out = new ArrayList<Integer>();
	public static int clock = 0;
	public static int tempclock = 0;
	private static int lastclock = 0;
	public static PrintStream console = System.out;
	public static PrintStream outfile ;
	public static int IOClock = 0;
	public static String[] param;
	public static int discLoc = 0;
	public static List<String> pageSnapshot = new ArrayList<String>();
	
	public static void main(String[] args){
		
		param = args;
		console = System.out;
		enableOutput();
		
		try{
			
		
				File f = new File("trace_file.txt");
				if (f.exists()) {
					f.delete();
				}
		//		System.setOut(new PrintStream(new ByteArrayOutputStream()));
				

			
			SYSTEM.load(loadLoaderFormat());
			
			CPU.cpuProc(MEMORY.initialPc, MEMORY.trace);

			System.out.println("===============================END EXECUTION===============================");
			
			
			
			
			System.out.println("===============================OUTPUT===============================");

			System.out.println("INPUT : "+new String(BASE_CPU.decToBin(out.get(0))));
			System.out.println("RESULT : "+new String(BASE_CPU.decToBin(out.get(1))) +"  "+BASE_CPU.decToHex(out.get(1)));
			System.out.println("CLOCL in vtu  : "+BASE_CPU.decToHex(clock));
			
			int val1 = (8-(DISC.counter%8)) + DISC.counter;
			String Input = MEMORY.memoryProc(0, val1, null);
			
			
			int val = (8-(DISC.counter%8)) + DISC.counter +8;
			String Output1 = MEMORY.memoryProc(0, val, null);
			String Output2 = MEMORY.memoryProc(0, val+1, null);
			
			changeToOutput();
				System.out.println("===============================OUTPUT===============================");
				System.out.println("JOB ID (Bin) : " + MEMORY.jobId);
		
				
				System.out.println("INPUT (Bin) : "+Input + " ,  JOB ID  : "+MEMORY.jobId);
				
				System.out.println("OUTPUT (Bin) : "+Output1 + " ,  JOB ID  : "+MEMORY.jobId);
				
				System.out.println("             : "+Output2  +" ,  JOB ID  : "+MEMORY.jobId);
				System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
				System.out.println("IO Time  (Dec) :" + IOClock);
				System.out.println("Execution Time (Dec) :" + (clock - IOClock));
				System.out.println("PAGE FAULT  Time (Dec) : " + PAGEFAULT_HANDLER.PF_CLOCK);
				System.out.println("SEGMENT FAULT  Time (Dec) :" + SEGMENT_FAULT.SF_CLOCK);
				MEMORY.printMemoryUtilz();
				DISC.printDskUtilization();
				MEMORY.printMemFragmentation();
				DISC.printDskFragment();
				
				
				LOADER.initvar();
				
				if(MEMORY.trace == 1){
					enableTrace();
					System.out.println("**************************************TRACE OUTPUT (in HEX)****************************************");
					System.out.println(" PC     BR   IR   TOS_BF  S[TOS]_BF  EA_BF   (EA)_BF    TOS_AF  S[TOS]_AF    EA_AF   (EA)_AF	 ");
					System.out.println();
					TRACE.getTraceList().stream().forEach(System.out :: println);
				}
				changeToOutput();
				System.out.println("NORMAL TERMINATION .");
				
		}catch(Exception e){
			
			if(e.getMessage().contains("ERROR") || e.getMessage().contains("WARNING")){
			
				System.out.println(e.getMessage());
				changeToOutput();
				System.out.println("JOB ID (Bin) : " + 1);
				System.out.println("CLOCL value (Hex)  : "+BASE_CPU.decToHex(clock));
				System.out.println(e.getMessage());
			}
			else{
				ERROR_HANDLER.handle(0);
			}
			changeToOutput();
			System.out.println("ABNORMAL TERMINATION .");
		}
		
		printPageSnapsAtClckIntr();
	}
	
	public static void writeio(Integer val){
		out.add(val);
		clock = clock +15;
		SYSTEM.logClock();
	}
	
	
	//****** Reading the input loader format to DISC*****//
	public static Supplier<Stream<String>> loadLoaderFormat(){
		Supplier<Stream<String>> streamSupplier = () -> {
			try {
			
				return Files.lines(Paths.get(ClassLoader.getSystemResource("finput.txt").toURI()));
			} catch (IOException | URISyntaxException e) {
				e.printStackTrace();
			}
			return null;
		};
		
		return streamSupplier;
	}
	
	//****** writing the output in output file ****//
	
	public static void enableOutput(){	
		try {
			outfile = (new PrintStream(new FileOutputStream("output.txt")));
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
	}
	
	public static void changeToOutput(){	
		System.setOut(outfile);
	}
	public static void changeToConsole(){	
		System.setOut(console);
	}
	
	public static void enableTrace(){
		
		try {
			System.setOut(new PrintStream(new FileOutputStream("trace_file.txt")));
		} catch (FileNotFoundException e) {		
			e.printStackTrace();
		}
	}
	
	
	
	//************* Adding data to DISC ***********//

	public static void load(Supplier<Stream<String>> streamSupplier){
		
		loadEach(streamSupplier);
		
//		LOADER.initvar();
		
///		vaidateJob(streamSupplier);
		
		
//		String jobDetails =  streamSupplier.get()
//										.skip(1)  // exclude **JOB 06 02
//										.findFirst()
//										.get();
//		MEMORY.addJobParams(jobDetails);
//		PCB.getInstance(CPU.currentJob).setJobId(MEMORY.jobId);
		
		
//		addToDisc(streamSupplier);
		
	}
	
	
	private static void loadEach(Supplier<Stream<String>> streamSupplier){
		
		int jcount = 0;
		boolean  jStart = false;
		boolean  prgStart = false;
		boolean  inStart = false;
		Integer jobId =  null;
		
		Iterator<String> it = streamSupplier.get().iterator();
		
		 while(it.hasNext()) {
			 String line = it.next();
			
			 
			 
			 if(line.startsWith("**JOB")){
				 	jStart = true;
				 	prgStart = true;
				 	jobId = addJobParams(it.next()).getJobId();  // extract job params and set to PCB
				 	System.out.println("Inside Job ");
				 	continue;
				}
			 else if(line.startsWith("**INPUT")){
				 	prgStart = false;
				 	inStart = true;
				 	discLoc = discLoc + (discLoc%8);
				 	System.out.println("Inside Input");
				 	continue;
			 }
			 else if(line.startsWith("**FIN")){
				 
				 //validate
				 
				 if(!jStart){
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER113);
				 }else if(jStart && !inStart){
					 ERROR_HANDLER.handle(ERROR_HANDLER.ER114);
				 }
				 
				 	jStart = false;
				 	prgStart = false;
				 	inStart = false;
				 	jobId = null;
					jcount++;
					System.out.println("Inside Finish :: "+jcount);
			 }
			 
			 
			 if(jStart && prgStart){
				 System.out.println("Line "+discLoc);
				 addWordsToDisc(line);
				 
			 }else if(jStart && inStart && !prgStart){
				 addInputToDisc(line);
			 }
			 
			 
		 }
		
		
		
	}
	
	
	public static void addToDisc(Supplier<Stream<String>> streamSupplier){
		
		boolean input = false;
		int discLoc = 0;
		
		Iterator<String> it = streamSupplier.get()
						.skip(2)
						.iterator();
		
		
		while(it.hasNext()){
			String item =  it.next();
			if(item.contains("**INPUT")){
				input = true;				
				continue;
			}else if(item.contains("**FIN")){
				break;
			}
			
			if(input){
				int page =   (int) Math.ceil(((discLoc/8) * 1000000)/1000000);
				
				addInputToDisc(item);
				CPU.init(Integer.parseInt(item, 16));
				
			}else{
				addWordsToDisc(item);
			}			
			
		}
		
		
	}
	
	
	private static void addInputToDisc(String word){
		if(word.length()!=4){
	//		ERROR_HANDLER.handle(ERROR_HANDLER.WR203);
		}	
		
		if(! word.matches("^[0-9A-F/-]+$")){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER119);
		}
		DISC.addToDisk(hexToBinary(word), discLoc);
		
	}
	
	
	private static void addWordsToDisc(String line){
				if(line.length()!=16){					
					ERROR_HANDLER.handle(ERROR_HANDLER.ER101);
				}
				for(int i=0;i<16;i=i+4){
					String word = line.substring(i,i+4);
					DISC.addToDisk(hexToBinary(word), discLoc);
					DISC.counter++;
					discLoc++;
				}
	}
	

public static void vaidateJob(Supplier<Stream<String>> streamSupplier){
		
		String fLine = streamSupplier.get().findFirst().get();
		if(!fLine.contains("**JOB")){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER113);
		}
		
		boolean isInput = streamSupplier.get().anyMatch(n -> n.contains("**INPUT"));
		if(!isInput)
			ERROR_HANDLER.handle(ERROR_HANDLER.ER114);
		
		
		boolean isFin = streamSupplier.get().anyMatch(n -> n.contains("**FIN"));
		if(!isFin)
			ERROR_HANDLER.handle(ERROR_HANDLER.ER115);
		
		long mulin =  streamSupplier.get().filter(n -> n.contains("**INPUT")).count();
						
		System.out.println(mulin);
		if(mulin>1)
			ERROR_HANDLER.handle(ERROR_HANDLER.ER116);
		
		
	}
	
	private static String hexToBinary(String hex) {
	    int i = Integer.parseInt(hex, 16);
	    String bin = Integer.toBinaryString(i);
	    return bin;
	}
	
	private static void printPageSnapsAtClckIntr(){
	
		pageSnapshot.stream().forEach(System.out::println);
	
	}
	
	
	//********* Clock interval for printing PMT *********//
	
	public static void logClock(){
		if((clock - lastclock) >= 15){
			StringBuilder snap =  new StringBuilder();
			tempclock= tempclock + 15;
			snap.append("At Clock Value  "+ tempclock  +" :: ");
			for(int i=0;i<32 ;i++){
////				int page = PCB.pageFrameTableCollect[0][i][0];
//				if(page != -1){
//					snap.append("Frame: "+i+" --> Page: "+page+ " , ");
//				}
			}				
			pageSnapshot.add(snap.toString());
			snap.setLength(0);
			lastclock = clock;
		}				
}
	
	
private static PCB addJobParams(String hex){
	
	PCB pcb = null;
	
		try{
			System.out.println("JOB_ID :: "+ hex.substring(0, 2));
			System.out.println("LOAD ADDR :: " +hex.substring(3, 5));
			System.out.println("INITIAL_PC :: "+hex.substring(6, 8));
			System.out.println("SIZE :: "+hex.substring(9, 11));
			System.out.println("TRACE FLAG :: "+hex.substring(12, 13));
		}catch(Exception e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER112);
		}
		
		
		if((!hex.substring(12, 13).trim().equals("0")) && (!hex.substring(12, 13).trim().equals("1"))){
			ERROR_HANDLER.handle(ERROR_HANDLER.WR202);
		}	
		
		try{
			Integer jobId =  Integer.parseInt(hex.substring(0, 2), 16);
			pcb = PCB.getInstance(jobId);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER107);
		}
		
		try{
			Integer loadAddr =  Integer.parseInt(hex.substring(3, 5), 16);
			pcb.setLoadAddrs(loadAddr);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER108);
		}
		
		try{
			Integer initialPc = Integer.parseInt(hex.substring(6, 8), 16);
			pcb.setInitialProgramCounter(initialPc);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER109);
		}
		
		try{
			Integer size =  Integer.parseInt(hex.substring(9, 11), 16);
			pcb.setJobSize(size);
		}catch(NumberFormatException e){
			ERROR_HANDLER.handle(ERROR_HANDLER.ER110);
		}

			
		Integer trace =  Integer.parseInt(hex.substring(12, 13), 16);
		pcb.setTrace(trace);
		
		return pcb ;
	}

}



