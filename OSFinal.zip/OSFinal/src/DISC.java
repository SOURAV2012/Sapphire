/*
 * DISC class getting data from SYSTEM.
 * Storing each word in each location.
 * Size of the DISC size is 8 times of memory.
 * DISC used as virtual memory.
 * 
 */
import java.util.Arrays;

public class DISC {
	
	
	private static  char disk[][] = new char[2048][16];
	
	// create segment table while adding to disk
	public static int counter = -1;
	
	public static void addToDisk(String bin,int pos){	
		String pad = "0000000000000000" + bin;         // padding
		bin = pad.substring(pad.length()-16);					
		disk[pos] = bin.toCharArray();
		
	}
	
	
	public static char[] readFromDisk(int pos){
	
		return disk[pos];		
	}
	
	
	
	
	public static void printContent(){
		
		Arrays.stream(disk)
		.map(n->new String(n))
		.forEach( n -> System.out.println(n));
	}
	
	//**************** Disc Utilization ************//
	public static void printDskUtilization(){
		
		
		double dskUtilWr = (double)(counter+1+1+2)/2048;
		double dskUtilFr = (double)MEMORY.pageset.size()/(2048/8);
	
		System.out.println("DISC UTILIZATION WORDS --  Ratio :"+ dskUtilWr + "  Percentage :"+(dskUtilWr *100) +"%");
		System.out.println("DISC UTILIZATION FRAMES --  Ratio :"+ dskUtilFr + "  Percentage :"+(dskUtilFr *100) +"%");
		
	}
	
	//************ Disc Fragmentation ***********//
	
	public static void printDskFragment(){
		int emptyCount = 0;
		int page = MEMORY.pageNumFromDskAddrs(counter);
		for(int i=0;i<8;i++){
			 String item = new String(readFromDisk((page*8)+i));
			 if(item.trim().isEmpty())
				 emptyCount ++;
		}
		
	
		emptyCount = (emptyCount + 7 + 6) / 3;
		System.out.println("DISC FRAGMENTATION : "+emptyCount);
	}

}
